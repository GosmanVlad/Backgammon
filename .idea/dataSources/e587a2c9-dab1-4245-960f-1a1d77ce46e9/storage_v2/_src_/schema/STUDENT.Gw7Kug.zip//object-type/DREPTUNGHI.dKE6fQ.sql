create TYPE dreptunghi AS OBJECT ( 
  lungime NUMBER,
  latime NUMBER,
  MAP MEMBER FUNCTION area RETURN NUMBER);
/

