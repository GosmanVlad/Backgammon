create PACKAGE calculator AS 
   function calcul (n1 NUMBER, n2 NUMBER) return NUMBER;
END calculator;
/

