create PACKAGE STUDENTI_BURSA AS 
   PROCEDURE find_bursa (s_id studenti.id%type); 
END studenti_bursa;
/

