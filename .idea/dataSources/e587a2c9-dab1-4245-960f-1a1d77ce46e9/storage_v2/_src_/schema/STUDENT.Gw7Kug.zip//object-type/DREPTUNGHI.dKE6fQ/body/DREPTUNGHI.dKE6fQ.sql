create TYPE BODY dreptunghi AS 
  MAP MEMBER FUNCTION area RETURN NUMBER IS
  BEGIN
     RETURN lungime * latime;
  END area;
END;
/

