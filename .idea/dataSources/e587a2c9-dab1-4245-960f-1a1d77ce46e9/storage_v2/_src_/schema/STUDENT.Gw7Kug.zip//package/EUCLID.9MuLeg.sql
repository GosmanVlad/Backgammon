create PACKAGE euclid AS 
   procedure cmmdc (n1 NUMBER, n2 NUMBER);
END euclid;
/

