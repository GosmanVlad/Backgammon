create PACKAGE BODY STUDENTI_BURSA AS
  PROCEDURE find_bursa (s_id studenti.id%type) AS
  s_bursa studenti.bursa%TYPE; 
  s_nume studenti.nume%TYPE;
  BEGIN
    SELECT nume INTO s_nume FROM studenti
    WHERE id=s_id;
    SELECT bursa INTO s_bursa FROM studenti
    WHERE id=s_id;
    dbms_output.put_line('Numele acestui student:' || s_nume);
    dbms_output.put_line('Bursa acestui student: ' || s_bursa ||' lei');
  END find_bursa;
END STUDENTI_BURSA;
/

