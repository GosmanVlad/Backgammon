create PACKAGE BODY euclid AS
  procedure cmmdc (n1 NUMBER, n2 NUMBER) AS
  rezultat number;
  BEGIN
    WHILE n1!=n2
    LOOP
       IF n1>n2 THEN
       n1 := n1-n2;
       ELSE
       n2 := n2-n1;
       END IF;
    END LOOP;
    rezultat:=n1;
    dbms_output.put_line('CMMDC-ul acestor numere este'|| rezultat);
  END cmmdc;
END euclid;
/

