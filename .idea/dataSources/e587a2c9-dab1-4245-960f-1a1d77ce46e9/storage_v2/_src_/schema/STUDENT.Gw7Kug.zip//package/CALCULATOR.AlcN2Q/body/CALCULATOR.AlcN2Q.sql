create PACKAGE BODY CALCULATOR AS
  function calcul (n1 NUMBER, n2 NUMBER) return NUMBER AS
  rezultat number;
  BEGIN
    rezultat := n1+n2;
    RETURN rezultat;
  END calcul;
END CALCULATOR;
/

